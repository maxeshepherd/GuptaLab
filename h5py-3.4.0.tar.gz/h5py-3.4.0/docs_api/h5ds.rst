Module H5DS
===========

.. automodule:: h5py.h5ds
    :members:
